#criar um programa que pergunte se voce quer sair do programa
#se sim, saia
pergunta = input('Deseja continuar no programa? responda (s / n): ')

while pergunta == 's':
    pergunta = input('Deseja continuar no programa? responda (s / n): ')
  