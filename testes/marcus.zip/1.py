#Exercicio 1:
#fazer entregas de compras online
#entregar pacotes em casas

pacotes_restantes = 5
while pacotes_restantes > 0:
    print(f'entregando pacotes{pacotes_restantes}')
    pacotes_restantes -= 1