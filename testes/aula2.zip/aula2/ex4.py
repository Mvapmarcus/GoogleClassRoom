notas = {
    "João" : 8,
    "Maria" : 6,
    "Pedro" : 7,
    "Ana" : 9,
}
for nome , nota in notas.items():
    if nota <= 7:
        continue
    else:  
        print(f"{nome} : {nota}")