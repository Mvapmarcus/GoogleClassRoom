livro = {
    "titulo" : "Python para iniciantes",
    "autor" : "João Silva",
    "ano" : 2020,
    "editora" : "TechBooks"
}
print(livro["titulo"])
# print(livro["preço"]) # Essa chave não existe no dicionário portanto não é possivel acessa-la sem o .get
print(livro["autor"])
print(livro.get("preço"))
print(len(livro))
print("ano" in livro)
atualização = {
    "preço": 49.90 
} 
livro.update(atualização)
livro["desconto"] = "10%"
print(livro)
livro["ano"] = 2023
print(livro)
del livro["editora"]
print(livro)
for chave, valor in livro.items():
    print(f'\n {chave} : {valor}')