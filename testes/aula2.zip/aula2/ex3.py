preços = {
    "produto_a" : 100,
    "produto_b" : 150,
    "produto_c" : 200
}

for chave, valor in preços.items():
    valor_novo =  valor * 0.9
    preços[chave] = valor_novo
print(preços)