#guardar nome / idade / nota / aprovação ou não

aluno = {
        "nome" : "Marcus",
        "idade" : 34,
        "nota" : 10,
        "aprovado" : True 
        }
aluno["nome"] = "Claudio"
print(aluno["nome"])


