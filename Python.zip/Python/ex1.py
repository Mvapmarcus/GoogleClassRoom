palestrante = ("Marcus Vinicius","Joao Pedro","Ana Clara")
tema = ("Python", "JavaScript", "Java")
instituicao = ("IFBA", "UNEB", "UFBA")

print (f"Palestrante : {palestrante[2]}\n tema: {tema[2]}\n instituicao: {instituicao[2]}") # imprime o terceiro item de cada tupla