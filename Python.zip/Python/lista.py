lista_de_numeros = ["ANA",'maria', 'joao', 'pedro', 'luan']
notas = [10, 9, 8, 7, 6]

for i in lista_de_numeros:
    print(i)