#adição de itens .append()
lista_de_brasileiros = ['maria', 'joao', 'pedro', 'luan']
lista_de_brasileiros.append('ana')
print(lista_de_brasileiros) # adiciona 'ana' ao final da lista

# remoção de itens .remove()
lista_de_brasileiros.remove('joao')
print(lista_de_brasileiros) # remove 'joao' da lista 

# ordenação de itens .sort()
lista_de_brasileiros.sort()
print(lista_de_brasileiros) # ordena a lista em ordem alfabética

# acesso a itens por índice
print(lista_de_brasileiros[2]) # imprime o terceiro item (índice 2) da lista
print(lista_de_brasileiros[-2]) # imprime o penúltimo item da lista

# adicionar items no início da lista .insert()
lista_de_brasileiros.insert(0, 'carlos')
print(lista_de_brasileiros) # adiciona 'carlos' no início da lista

# remover o último item .pop()
ultimo_item = lista_de_brasileiros.pop()
print(ultimo_item) # imprime o último item removido
print(lista_de_brasileiros) # mostra a lista após a remoção do último item