# difinição de lista 

lista_de_compras = ['arroz', 'feijão', 'macarrão', 'carne', 'frutas']

print("Lista de compras:", end = "\n\n")# imprime o título da lista e pula uma linha (end="\n\n")

for i in lista_de_compras:
    print("[ ]",i)