notas = [10, 9, 8, 7, 6]

print(notas[2])# ordem da esquerda para a direita
print(notas[-2])# ordem da direita para a esquerda