notas = [7,8,9]

soma = sum(notas)
quantidade = len(notas)

media = soma / quantidade

print(f"A média das notas é: {media:.2f}")  # Formata a média para duas casas decimais